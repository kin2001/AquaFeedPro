# AquaFeedPro UI4 implementation reference — 2026-10-29
Parent issue: https://linear.app/artkin/issue/ART-117

## Open the reference
Open reference.html in a browser. This standalone HTML file embeds the approved mascot and app icon and requires no localhost server, packages, or credentials. It is design evidence only, not a native implementation or functional specification.
The underlying approved snapshot is app-icon-v10.html: revision 07 neutral surfaces + revision 09 supplied mascot + revision 10 supplied icon. Do not substitute older full-screen-color drafts.

## What is included
- reference.html: exact latest approved interactive design reference.
- design-contract.md: parent issue specification at creation.
- ART-118.md ... ART-122.md: individual native implementation issue scopes and acceptance criteria.
- assets/aquafeedpro-mascot.png: full mascot, unchanged source.
- assets/aquafeedpro-app-icon-v2-three-quarter.png: selected app icon, unchanged source.
- inspiration-layout.png: user-supplied travel UI reference for neutral surfaces and floating controls only.
- manifest-sha256.json: checksums of all packaged files.

## Essential interpretation
Implement in the existing React Native / Expo / TypeScript / Expo Router app with installed Reanimated, SVG, Gesture Handler and existing shared components; no WebView, HTML implementation or new libraries.
Preserve complete functionality, all routes/subpages, validations and device/backend semantics. HTML data and handlers are illustrative and must never replace the integrated app logic. Appearance and motion preferences are local presentation settings only.
All implementers/reviewers must read $ponytail:ponytail full and $ui-ux-pro-max. See the parent and each child issue.

The reference includes collapsed/scrollable/interactive states. Click all tabs, Settings appearance/motion controls, chart range, and Feed now. There are two phone previews; some narrow browser windows stack them. Example 2 kg capacity, dose values, timestamps, counts and Pond 01 are illustrative, not new product constraints. Existing production capacity/dose limits and current state must be preserved.
Dark theme can be explored in Settings; it is neutral charcoal with localized graph color. Respect OS reduced motion.
Unpictured native screens inherit the same tokens/type/controls/sheets and keep all existing content.
No live feeder/backend connection exists in this reference. No API keys or project secrets are included.
